x = int(input("Please enter your's x value:"))
y = int(input("Please enter your's y value:"))
print("Your values: " + str(x) + " and " + str(y))
sumres = x + y
print("Sum of ", x, "+", y, "=", sumres)
sumdiv = x / y
print("Integer division of: ", x, "/", y, "=", int(sumdiv))
sumleft = x // y
print("Remainder of the division: ", x, "//", y, "=", sumleft)
sumdeg = x ** y
print("Degree of: ", x, "^", y, "=", sumdeg)