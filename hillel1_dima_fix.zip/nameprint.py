"""print("***\t\t\t****\t\t***\t\t\t\t\t **\t\t\t\t\t **")
print("****\t\t****\t\t****\t\t\t\t***\t\t\t\t\t****")
print("**\t**\t\t\t\t\t** **\t\t\t   ****\t\t\t\t   *** ***")
print("**\t **\t\t****\t\t**\t**\t\t\t  *****\t\t\t\t  **     **")
print("**\t ***\t****\t\t**\t **\t\t\t **\t **\t\t\t\t **       **")
print("**\t ***\t****\t\t**\t  **\t\t**\t **\t\t\t    **         **")
print("**\t ***\t****\t\t**\t   **\t   **\t **\t\t\t  ****************")
print("**\t ***\t****\t\t**\t\t**\t  **\t **\t\t\t ******************")
print("**\t **\t\t****\t\t**\t\t **\t **\t\t **\t\t\t**\t\t\t\t  **")
print("**\t**\t\t****\t\t**\t\t   ***\t\t **\t\t   **\t\t\t\t   **")
print("****\t\t****\t\t**\t\t\t\t\t **\t\t  **\t\t\t\t\t**")
print("***\t\t\t****\t\t**\t\t\t\t\t **\t\t **\t\t\t\t\t\t **")"""

print("***\t\t\t****\t\t***\t\t\t\t\t **\t\t\t\t\t **\n****\t\t****\t\t****\t\t\t\t***\t\t\t\t\t****\n**\t **\t\t****\t\t**\t**\t\t\t  *****\t\t\t\t  **     **\n**\t ***\t****\t\t**\t **\t\t\t **\t **\t\t\t\t **       **\n**\t ***\t****\t\t**\t  **\t\t**\t **\t\t\t    **         **\n**\t ***\t****\t\t**\t   **\t   **\t **\t\t\t  ****************\n**\t ***\t****\t\t**\t\t**\t  **\t **\t\t\t ******************\n**\t **\t\t****\t\t**\t\t **\t **\t\t **\t\t\t**\t\t\t\t  **\n**\t**\t\t****\t\t**\t\t   ***\t\t **\t\t   **\t\t\t\t   **\n****\t\t****\t\t**\t\t\t\t\t **\t\t  **\t\t\t\t\t**\n***\t\t\t****\t\t**\t\t\t\t\t **\t\t **\t\t\t\t\t\t **")