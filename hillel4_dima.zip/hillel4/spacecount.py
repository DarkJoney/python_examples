"""Дана строка, состоящая из слов, разделенных пробелами. Определите, сколько в ней слов. Используйте для решения
задачи функцию `count`"""

s = "Lorem ipsum dolor sit amet"
num = s.count(' ') + 1
print(s)
print("Number of the words at string is:", num)